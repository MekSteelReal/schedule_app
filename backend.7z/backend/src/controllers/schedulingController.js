// backend/src/controllers/schedulingController.js

exports.requestService = async (req, res) => {
    // Em um app real, o contratante_id viria do token de autenticação.
    // Para nosso MVP, vamos recebê-lo no corpo da requisição.
    const { 
        contratante_id, 
        contratado_id, 
        profissao_id, // ID da profissão para a qual o serviço está sendo solicitado
        titulo, // Título do serviço, ex: "Conserto de vazamento na pia da cozinha"
        descricao, // Descrição detalhada do que precisa ser feito
        localizacao_json, // Objeto JSON com endereço/coordenadas
        preco_proposto, // Preço que o contratante está oferecendo
        tipo_pagamento, // 'POR_HORA' ou 'PRECO_FIXO'
        data_inicio_agendada // Data e hora que o contratante sugere
    } = req.body;

    const db = req.db;

    // Validação dos campos essenciais
    if (!contratante_id || !contratado_id || !profissao_id || !titulo || !preco_proposto || !data_inicio_agendada) {
        return res.status(400).json({ message: 'Campos obrigatórios estão faltando.' });
    }

    // Usaremos uma transação para garantir que ambas as inserções (em Servicos e Agendamentos)
    // ocorram com sucesso. Se uma falhar, a outra é revertida.
    const client = await db.connect();

    try {
        await client.query('BEGIN'); // Inicia a transação

        // 1. Cria a entrada na tabela 'Servicos' para descrever a vaga/oportunidade
        const servicoQuery = `
            INSERT INTO servicos (contratante_id, profissao_id, titulo, descricao, localizacao_json, preco_proposto, tipo_pagamento, status)
            VALUES ($1, $2, $3, $4, $5, $6, $7, 'AGENDADO')
            RETURNING id;
        `;
        const servicoResult = await client.query(servicoQuery, [contratante_id, profissao_id, titulo, descricao, localizacao_json, preco_proposto, tipo_pagamento]);
        const servicoId = servicoResult.rows[0].id;

        // 2. Cria o agendamento associado, com status 'SOLICITADO'
        const agendamentoQuery = `
            INSERT INTO agendamentos (servico_id, contratado_id, preco_final, data_inicio_agendada, status)
            VALUES ($1, $2, $3, $4, 'SOLICITADO');
        `;
        await client.query(agendamentoQuery, [servicoId, contratado_id, preco_proposto, data_inicio_agendada]);

        await client.query('COMMIT'); // Confirma a transação
        res.status(201).json({ message: 'Solicitação de serviço enviada com sucesso!' });

    } catch (error) {
        await client.query('ROLLBACK'); // Desfaz a transação em caso de erro
        console.error('Erro ao solicitar serviço:', error);
        res.status(500).json({ message: 'Erro interno do servidor ao processar a solicitação.' });
    } finally {
        client.release(); // Libera a conexão com o banco
    }
};