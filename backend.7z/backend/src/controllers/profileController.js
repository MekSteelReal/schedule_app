// backend/src/controllers/profileController.js

// Lógica para o cliente buscar a lista de trabalhadores
exports.getAvailableWorkers = async (req, res) => {
    const db = req.db;
    try {
        // =================== QUERY CORRIGIDA ABAIXO ===================
        // Trocamos os nomes das tabelas para letras minúsculas e removemos as aspas duplas.
        const query = `
            SELECT 
                u.id,
                u.nome_completo,
                u.foto_perfil_url,
                pp.titulo_perfil,
                pp.preco_hora_base,
                pp.nota_media,
                p.nome as profissao_nome
            FROM usuarios u
            JOIN perfis_profissionais pp ON u.id = pp.usuario_id
            JOIN usuario_profissoes up ON u.id = up.usuario_id
            JOIN profissoes p ON up.profissao_id = p.id
            WHERE u.tipo_usuario IN ('CONTRATADO', 'AMBOS') AND u.ativo = TRUE;
        `;
        // ==============================================================

        const { rows } = await db.query(query);
        res.status(200).json(rows);

    } catch (error) {
        // Este console.error foi o que te ajudou a achar o erro!
        console.error('Erro ao buscar trabalhadores:', error); 
        res.status(500).json({ message: 'Erro interno do servidor ao buscar trabalhadores.' });
    }
};

// A outra função (createOrUpdateProfessionalProfile) não precisa ser alterada,
// pois os nomes das tabelas nela já estavam sem aspas e o PostgreSQL consegue interpretá-los.
// Mas por consistência, você pode alterá-la para minúsculas também se desejar.
exports.createOrUpdateProfessionalProfile = async (req, res) => {
    const { userId } = req.body;
    const { titulo_perfil, descricao_longa, preco_hora_base, profissao_id } = req.body;
    const db = req.db;

    if (!userId || !titulo_perfil || !preco_hora_base || !profissao_id) {
        return res.status(400).json({ message: 'Campos obrigatórios: userId, titulo_perfil, preco_hora_base, profissao_id' });
    }

    try {
        const query = `
            INSERT INTO perfis_profissionais (usuario_id, titulo_perfil, descricao_longa, preco_hora_base)
            VALUES ($1, $2, $3, $4)
            ON CONFLICT (usuario_id) 
            DO UPDATE SET 
                titulo_perfil = EXCLUDED.titulo_perfil,
                descricao_longa = EXCLUDED.descricao_longa,
                preco_hora_base = EXCLUDED.preco_hora_base;
        `;
        
        const professionQuery = `
            INSERT INTO usuario_profissoes (usuario_id, profissao_id)
            VALUES ($1, $2)
            ON CONFLICT (usuario_id, profissao_id) DO NOTHING;
        `;

        await db.query(query, [userId, titulo_perfil, descricao_longa, preco_hora_base]);
        await db.query(professionQuery, [userId, profissao_id]);

        res.status(200).json({ message: 'Perfil profissional salvo com sucesso!' });

    } catch (error) {
        console.error('Erro ao salvar perfil profissional:', error);
        res.status(500).json({ message: 'Erro interno do servidor ao salvar perfil.' });
    }
};

exports.getWorkerById = async (req, res) => {
    const { id } = req.params;
    const db = req.db;

    try {
        // =========== QUERY ATUALIZADA PARA INCLUIR profissao_id ===========
        const query = `
            SELECT 
                u.id,
                u.nome_completo,
                u.email,
                u.telefone,
                u.foto_perfil_url,
                u.data_cadastro,
                pp.titulo_perfil,
                pp.descricao_longa,
                pp.preco_hora_base,
                pp.nota_media,
                p.id as profissao_id, -- <-- ADICIONAMOS ESTA LINHA
                p.nome as profissao_nome
            FROM usuarios u
            LEFT JOIN perfis_profissionais pp ON u.id = pp.usuario_id
            LEFT JOIN usuario_profissoes up ON u.id = up.usuario_id
            LEFT JOIN profissoes p ON up.profissao_id = p.id
            WHERE u.id = $1;
        `;

        const result = await db.query(query, [id]);

        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Profissional não encontrado.' });
        }

        res.status(200).json(result.rows[0]);

    } catch (error) {
        console.error(`Erro ao buscar trabalhador com ID ${id}:`, error);
        res.status(500).json({ message: 'Erro interno do servidor.' });
    }
};