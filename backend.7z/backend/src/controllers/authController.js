const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// Função de Registro ATUALIZADA para o novo banco de dados
exports.register = async (req, res) => {
  // 1. Extrair os dados do corpo da requisição
  const { 
    nome_completo, 
    email, 
    senha, // A senha vem em texto plano do frontend
    telefone, 
    cpf, 
    data_nascimento, 
    tipo_usuario 
  } = req.body;
  
  const db = req.db;

  // 2. Validação dos campos obrigatórios
  if (!nome_completo || !email || !senha || !telefone || !cpf || !data_nascimento || !tipo_usuario) {
    return res.status(400).json({ message: 'Todos os campos são obrigatórios: nome, email, senha, telefone, cpf, data de nascimento e tipo de usuário.' });
  }

  try {
    // 3. Criptografar a senha antes de salvar no banco
    const senha_hash = await bcrypt.hash(senha, 10);

    // 4. Montar e executar a query SQL para inserir na tabela `Usuarios`
    const query = `
      INSERT INTO Usuarios (nome_completo, email, senha_hash, telefone, cpf, data_nascimento, tipo_usuario)
      VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING id, nome_completo, email, tipo_usuario, data_cadastro
    `;
    
    const values = [nome_completo, email, senha_hash, telefone, cpf, data_nascimento, tipo_usuario];
    
    const result = await db.query(query, values);
    const newUser = result.rows[0];

    // 5. Enviar uma resposta de sucesso
    res.status(201).json({ 
      message: 'Usuário registrado com sucesso!', 
      user: newUser 
    });

  } catch (error) {
    console.error('Erro ao registrar usuário:', error);
    // Tratamento de erro para e-mail ou CPF duplicado
    if (error.code === '23505') { // Código de violação de unicidade do PostgreSQL
      return res.status(409).json({ message: `Erro de duplicidade: ${error.detail}` });
    }
    // Erro genérico
    res.status(500).json({ message: 'Ocorreu um erro interno no servidor ao tentar registrar o usuário.' });
  }
};

// Função de Login ATUALIZADA para o novo banco de dados
exports.login = async (req, res) => {
  // 1. Extrair email e senha do corpo da requisição
  const { email, senha } = req.body;
  const db = req.db;

  // 2. Validação simples
  if (!email || !senha) {
    return res.status(400).json({ message: 'E-mail e senha são obrigatórios.' });
  }

  try {
    // 3. Buscar o usuário no banco de dados pelo e-mail
    const query = 'SELECT id, nome_completo, email, senha_hash, tipo_usuario, ativo FROM Usuarios WHERE email = $1';
    const result = await db.query(query, [email]);
    const user = result.rows[0];

    // 4. Verificar se o usuário existe e se está ativo
    if (!user) {
      return res.status(404).json({ message: 'Usuário não encontrado. Verifique o e-mail e tente novamente.' });
    }
    if (!user.ativo) {
        return res.status(403).json({ message: 'Esta conta foi desativada.' });
    }

    // 5. Comparar a senha enviada com o hash salvo no banco
    const senhaCorreta = await bcrypt.compare(senha, user.senha_hash);

    if (!senhaCorreta) {
      return res.status(401).json({ message: 'Senha incorreta.' });
    }

    // 6. Gerar o Token de Autenticação (JWT)
    const token = jwt.sign(
      { 
        userId: user.id, 
        userType: user.tipo_usuario // Usando o novo nome do campo
      },
      process.env.JWT_SECRET, // Certifique-se que seu .env tem essa variável!
      { expiresIn: '24h' }
    );

    // 7. Enviar a resposta de sucesso com o token e os dados do usuário
    res.status(200).json({
      message: 'Login bem-sucedido!',
      token,
      user: {
        id: user.id,
        nome: user.nome_completo,
        email: user.email,
        tipoUsuario: user.tipo_usuario,
      },
    });

  } catch (error) {
    console.error('Erro ao fazer login:', error);
    res.status(500).json({ message: 'Ocorreu um erro interno no servidor ao tentar fazer login.' });
  }
};