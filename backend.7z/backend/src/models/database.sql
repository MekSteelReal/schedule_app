-- SCRIPT DE CRIAÇÃO DO BANCO DE DADOS PARA O APP SCHEDULE
-- Versão: 2.0
-- Data: 06 de Agosto de 2025
-- Autor: Gemini AI
--
-- Descrição: Este script cria todas as tabelas, tipos, chaves e índices
-- necessários para a operação do aplicativo Schedule em um banco de dados PostgreSQL.
------------------------------------------------------------------------------------

-- PASSO 1: CRIAÇÃO DOS TIPOS ENUMERADOS (ENUMs)
-- Isso garante a consistência dos dados em campos com valores pré-definidos.

CREATE TYPE TIPO_USUARIO AS ENUM ('CONTRATANTE', 'CONTRATADO', 'AMBOS');
CREATE TYPE STATUS_VERIFICACAO_DOC AS ENUM ('PENDENTE', 'APROVADO', 'REPROVADO');
CREATE TYPE TIPO_PAGAMENTO_SERVICO AS ENUM ('POR_HORA', 'PRECO_FIXO');
CREATE TYPE STATUS_SERVICO AS ENUM ('ABERTO', 'AGENDADO', 'CONCLUIDO', 'CANCELADO');
CREATE TYPE STATUS_AGENDAMENTO AS ENUM ('SOLICITADO', 'ACEITO', 'RECUSADO', 'EM_ANDAMENTO', 'CONCLUIDO', 'CANCELADO_PELO_CONTRATANTE', 'CANCELADO_PELO_CONTRATADO');
CREATE TYPE STATUS_TRANSACAO AS ENUM ('PENDENTE', 'PAGO', 'FALHOU', 'REEMBOLSADO');

-- PASSO 2: CRIAÇÃO DAS TABELAS
-- A ordem de criação é importante para respeitar as chaves estrangeiras.

-- Tabela principal de usuários
CREATE TABLE IF NOT EXISTS Usuarios (
    id SERIAL PRIMARY KEY,
    nome_completo VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    senha_hash VARCHAR(255) NOT NULL, -- IMPORTANTE: Armazenar sempre o hash da senha, nunca a senha em texto plano.
    telefone VARCHAR(20) NOT NULL UNIQUE,
    cpf VARCHAR(14) NOT NULL UNIQUE, -- IMPORTANTE: Considerar criptografar este dado em repouso.
    rg VARCHAR(20),
    data_nascimento DATE NOT NULL,
    foto_perfil_url VARCHAR(255),
    tipo_usuario TIPO_USUARIO NOT NULL,
    endereco_json JSONB, -- Ex: {"cep": "50000-000", "rua": "...", "cidade": "Recife", "estado": "PE", "latitude": -8.0, "longitude": -34.0}
    contato_emergencia_json JSONB, -- Ex: {"nome": "Maria", "telefone": "81999998888"}
    data_cadastro TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    ativo BOOLEAN DEFAULT TRUE
);

-- Tabela de catálogo de profissões
CREATE TABLE IF NOT EXISTS Profissoes (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE,
    descricao TEXT,
    requer_doc_especifico BOOLEAN DEFAULT FALSE
);

-- Tabela de perfil para prestadores de serviço (1-para-1 com Usuarios)
CREATE TABLE IF NOT EXISTS Perfis_Profissionais (
    usuario_id INTEGER PRIMARY KEY,
    titulo_perfil VARCHAR(100),
    descricao_longa TEXT,
    preco_hora_base DECIMAL(10, 2) CHECK (preco_hora_base >= 0),
    disponivel_agora BOOLEAN DEFAULT FALSE,
    raio_atuacao_km INTEGER,
    nota_media DECIMAL(3, 2) DEFAULT 0.0,
    CONSTRAINT fk_usuario
        FOREIGN KEY(usuario_id)
        REFERENCES Usuarios(id)
        ON DELETE CASCADE -- Se o usuário for deletado, seu perfil profissional também será.
);

-- Tabela de perfil para contratantes (1-para-1 com Usuarios)
CREATE TABLE IF NOT EXISTS Perfis_Contratantes (
    usuario_id INTEGER PRIMARY KEY,
    descricao_perfil TEXT,
    nota_media_contratante DECIMAL(3, 2) DEFAULT 0.0,
    total_servicos_contratados INTEGER DEFAULT 0,
    identidade_verificada BOOLEAN DEFAULT FALSE,
    metodo_pagamento_verificado BOOLEAN DEFAULT FALSE,
    CONSTRAINT fk_usuario
        FOREIGN KEY(usuario_id)
        REFERENCES Usuarios(id)
        ON DELETE CASCADE -- Se o usuário for deletado, seu perfil de contratante também será.
);

-- Tabela de junção para associar usuários a múltiplas profissões
CREATE TABLE IF NOT EXISTS Usuario_Profissoes (
    usuario_id INTEGER NOT NULL,
    profissao_id INTEGER NOT NULL,
    PRIMARY KEY (usuario_id, profissao_id), -- Chave primária composta para garantir unicidade
    CONSTRAINT fk_usuario
        FOREIGN KEY(usuario_id) REFERENCES Usuarios(id) ON DELETE CASCADE,
    CONSTRAINT fk_profissao
        FOREIGN KEY(profissao_id) REFERENCES Profissoes(id) ON DELETE CASCADE
);

-- Tabela para armazenar documentos enviados pelos usuários
CREATE TABLE IF NOT EXISTS Documentos_Usuario (
    id SERIAL PRIMARY KEY,
    usuario_id INTEGER NOT NULL,
    tipo_documento VARCHAR(50) NOT NULL,
    url_arquivo VARCHAR(255) NOT NULL,
    status_verificacao STATUS_VERIFICACAO_DOC DEFAULT 'PENDENTE',
    data_envio TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    data_verificacao TIMESTAMPTZ,
    CONSTRAINT fk_usuario
        FOREIGN KEY(usuario_id) REFERENCES Usuarios(id) ON DELETE CASCADE
);

-- Tabela para as vagas/oportunidades de serviço criadas pelos contratantes
CREATE TABLE IF NOT EXISTS Servicos (
    id SERIAL PRIMARY KEY,
    contratante_id INTEGER NOT NULL,
    profissao_id INTEGER NOT NULL,
    titulo VARCHAR(150) NOT NULL,
    descricao TEXT NOT NULL,
    localizacao_json JSONB,
    preco_proposto DECIMAL(10, 2) NOT NULL,
    tipo_pagamento TIPO_PAGAMENTO_SERVICO NOT NULL,
    data_criacao TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    status STATUS_SERVICO DEFAULT 'ABERTO',
    CONSTRAINT fk_contratante
        FOREIGN KEY(contratante_id) REFERENCES Usuarios(id) ON DELETE CASCADE,
    CONSTRAINT fk_profissao
        FOREIGN KEY(profissao_id) REFERENCES Profissoes(id) ON DELETE RESTRICT -- Impede deletar uma profissão se houver serviços associados
);

-- Tabela que representa o "match" entre um serviço, um contratante e um contratado
CREATE TABLE IF NOT EXISTS Agendamentos (
    id SERIAL PRIMARY KEY,
    servico_id INTEGER NOT NULL,
    contratado_id INTEGER NOT NULL,
    preco_final DECIMAL(10, 2) NOT NULL,
    data_inicio_agendada TIMESTAMPTZ NOT NULL,
    data_fim_agendada TIMESTAMPTZ,
    data_inicio_real TIMESTAMPTZ,
    data_fim_real TIMESTAMPTZ,
    status STATUS_AGENDAMENTO DEFAULT 'SOLICITADO',
    codigo_confirmacao VARCHAR(10),
    CONSTRAINT fk_servico
        FOREIGN KEY(servico_id) REFERENCES Servicos(id) ON DELETE CASCADE,
    CONSTRAINT fk_contratado
        FOREIGN KEY(contratado_id) REFERENCES Usuarios(id) ON DELETE CASCADE
);

-- Tabela para registrar todas as transações financeiras
CREATE TABLE IF NOT EXISTS Transacoes (
    id SERIAL PRIMARY KEY,
    agendamento_id INTEGER NOT NULL,
    valor_bruto DECIMAL(10, 2) NOT NULL,
    taxa_plataforma DECIMAL(10, 2) NOT NULL,
    valor_liquido DECIMAL(10, 2) NOT NULL,
    metodo_pagamento VARCHAR(50) NOT NULL,
    id_transacao_gateway VARCHAR(255), -- ID retornado pelo Stripe, PayPal, etc.
    status STATUS_TRANSACAO DEFAULT 'PENDENTE',
    data_transacao TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_agendamento
        FOREIGN KEY(agendamento_id) REFERENCES Agendamentos(id) ON DELETE RESTRICT -- Impede deletar um agendamento se houver uma transação
);

-- Tabela para as avaliações mútuas
CREATE TABLE IF NOT EXISTS Avaliacoes (
    id SERIAL PRIMARY KEY,
    agendamento_id INTEGER NOT NULL,
    avaliador_id INTEGER NOT NULL,
    avaliado_id INTEGER NOT NULL,
    nota INTEGER NOT NULL CHECK (nota >= 0 AND nota <= 10), -- Mudado para 0-10 como no exemplo
    comentario TEXT,
    respostas_json JSONB, -- Para as perguntas específicas de feedback
    data_avaliacao TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (agendamento_id, avaliador_id), -- Garante que um usuário só pode avaliar um agendamento uma vez
    CONSTRAINT fk_agendamento
        FOREIGN KEY(agendamento_id) REFERENCES Agendamentos(id) ON DELETE CASCADE,
    CONSTRAINT fk_avaliador
        FOREIGN KEY(avaliador_id) REFERENCES Usuarios(id) ON DELETE SET NULL, -- Se o avaliador for deletado, a avaliação permanece
    CONSTRAINT fk_avaliado
        FOREIGN KEY(avaliado_id) REFERENCES Usuarios(id) ON DELETE SET NULL -- Se o avaliado for deletado, a avaliação permanece
);

-- PASSO 3: CRIAÇÃO DE ÍNDICES
-- Índices melhoram significativamente a performance de consultas em colunas usadas com frequência.

CREATE INDEX idx_usuarios_email ON Usuarios(email);
CREATE INDEX idx_servicos_contratante_id ON Servicos(contratante_id);
CREATE INDEX idx_servicos_profissao_id ON Servicos(profissao_id);
CREATE INDEX idx_agendamentos_servico_id ON Agendamentos(servico_id);
CREATE INDEX idx_agendamentos_contratado_id ON Agendamentos(contratado_id);
CREATE INDEX idx_avaliacoes_avaliado_id ON Avaliacoes(avaliado_id);

-- Fim do script. O banco de dados está pronto para ser utilizado.
-- Lembre-se de configurar a lógica de criptografia para os campos sensíveis na sua aplicação.