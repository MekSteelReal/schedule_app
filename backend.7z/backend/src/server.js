// Importação dos módulos
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { Pool } = require('pg');

// ===============================================================
// CORREÇÃO AQUI: Importe o ARQUIVO DE ROTAS, não o controller.
// ===============================================================
const authRoutes = require('./routes/authRoutes');
const profileRoutes = require('./routes/profileRoutes');
const scheduleRoutes = require('./routes/scheduleRoutes'); 
// Vamos deixar preparado para as próximas rotas também
// const serviceRoutes = require('./routes/serviceRoutes'); // Descomente quando criar este arquivo

// Configuração do Express
const app = express();
app.use(cors());
app.use(express.json());

// Configuração da Conexão com o Banco de Dados (PostgreSQL)
// Esta parte está correta.
const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_DATABASE,
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT,
});

// Middleware para injetar o pool de conexões em cada requisição
// Esta parte também está correta.
app.use((req, res, next) => {
  req.db = pool;
  next();
});


// ===============================================================
// CORREÇÃO NA LINHA ~33: Use a variável correta importada acima.
// ===============================================================
// Definição das Rotas da API
// Agora `authRoutes` é um objeto de rota do Express, que é o que `app.use` espera.
app.use('/api/auth', authRoutes);
app.use('/api/profile', profileRoutes); 
app.use('/api/schedule', scheduleRoutes);
// app.use('/api/services', serviceRoutes); // Descomente quando criar as rotas de serviço


// Rota de teste
app.get('/', (req, res) => {
  res.send('API do Schedule App está no ar!');
});

// Iniciar o servidor
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});