// backend/src/routes/scheduleRoutes.js
const express = require('express');
const router = express.Router();
const schedulingController = require('../controllers/schedulingController');

// Rota para um cliente solicitar um novo serviço/agendamento
// POST /api/schedule/request
router.post('/request', schedulingController.requestService);

module.exports = router;