// backend/src/routes/profileRoutes.js
const express = require('express');
const router = express.Router();
const profileController = require('../controllers/profileController');

// Rota para o trabalhador criar/atualizar o perfil
// PUT /api/profile/professional
router.put('/professional', profileController.createOrUpdateProfessionalProfile);

// Rota para buscar a lista de trabalhadores
// GET /api/profile/workers
router.get('/workers', profileController.getAvailableWorkers);

// =================================================================
// ADICIONE A NOVA ROTA PARA BUSCAR UM ÚNICO TRABALHADOR PELO ID
// GET /api/profile/worker/:id
router.get('/worker/:id', profileController.getWorkerById);
// =================================================================

module.exports = router;