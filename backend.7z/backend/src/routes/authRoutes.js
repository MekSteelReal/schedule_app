// Importa o framework Express para criar o roteador
const express = require('express');
// Cria uma nova instância do roteador do Express
const router = express.Router();

// Importa o controller que contém a lógica de registro e login
const authController = require('../controllers/authController');

// Define a rota POST para '/register'
// Quando uma requisição POST chegar em /api/auth/register, ela será
// encaminhada para a função 'register' dentro do nosso authController.
router.post('/register', authController.register);

// Define a rota POST para '/login'
// Da mesma forma, uma requisição POST para /api/auth/login será
// gerenciada pela função 'login' do authController.
router.post('/login', authController.login);

// Exporta o roteador configurado para que ele possa ser usado no server.js
module.exports = router;